import tkinter as tk

root = tk.Tk()

root.resizable(width=False, height=False)  # Permite o usuario mudar o tamanho da tela
root.geometry('750x750') # Cria uma janela 
root.configure(background = 'black')
root.title("Ludo - Grupo 5") #Nome da Janela

#Carregando as imagens
ImgCentro = tk.PhotoImage(file = "Imagens\\centro.gif")
ImgCaixaBranca = tk.PhotoImage(file = "Imagens\\caixabranca.gif") 
ImgCaixaEstrela = tk.PhotoImage(file = "Imagens\\caixaestrela.gif") 
#Imagens do Verde
ImgCaixaVerde = tk.PhotoImage(file = "Imagens\\caixaverde.gif")
ImgBaseVerde = tk.PhotoImage(file = "Imagens\\baseverde.gif")
ImgParadaVerde = tk.PhotoImage(file = "Imagens\\paradaverde.gif")
#Imagens do Vermelho
ImgCaixaVermelho = tk.PhotoImage(file = "Imagens\\caixavermelha.gif")
ImgBaseVermelho = tk.PhotoImage(file = "Imagens\\basevermelha.gif")
ImgParadaVermelho = tk.PhotoImage(file = "Imagens\\paradavermelha.gif")
#Imagens Azul
ImgCaixaAzul = tk.PhotoImage(file = "Imagens\\caixaazul.gif")
ImgBaseAzul = tk.PhotoImage(file = "Imagens\\baseazul.gif")
ImgParadaAzul = tk.PhotoImage(file = "Imagens\\paradaazul.gif")
#Imagens Amarelo
ImgCaixaAmarelo = tk.PhotoImage(file = "Imagens\\caixaamarelo.gif")
ImgBaseAmarelo = tk.PhotoImage(file = "Imagens\\baseamarelo.gif")
ImgParadaAmarelo = tk.PhotoImage(file = "Imagens\\paradaamarelo.gif")


def Tabuleiro():
    #Imagem Central
    tk.Label(image=ImgCentro, width=150, height=150).place(x=298, y=298)

    # Construindo o Lado Verde.
    vertical =  0 #quantidade de pixels para pular
    horizontal = 0
    conserta_caixa = 1 #Variavel de ajuda para implementar os quadrados colocridos

    tk.Label(image = ImgBaseVerde,width = 295,height = 300).place(x=-1,y=-1) #Base Verde
    while(horizontal != 300):
        vertical = 0
        while (vertical != 150):
            if horizontal == 50 and vertical ==0:
                tk.Label(image=ImgParadaVerde, width=46, height=46).place(x=(0 + horizontal), y=(300 + vertical)) #Insereindo a casa de parada do verde
            elif horizontal == 100 and vertical == 100:
                tk.Label(image=ImgCaixaEstrela, width=46, height=46).place(x=(0 + horizontal), y=(300 + vertical))
            elif conserta_caixa == 2 and horizontal > 0: #Verifica se é a caixa do meio e verifica de ja passou a primeira casa do meio.
                tk.Label(image=ImgCaixaVerde, width=46, height=46).place(x=(0 + horizontal), y=(300 + vertical)) #Inserindo as caixas verdes
            else:
                tk.Label(image=ImgCaixaBranca, width=46, height=46).place(x=(0 + horizontal), y=(300 + vertical)) #Inserindo as caixas brancas.
            vertical += 50
            conserta_caixa+=1
        conserta_caixa = 1
        horizontal+=50


    #Construindo o lado Vermelho
    vertical =  0 
    horizontal = 0
    conserta_caixa = 1 

    tk.Label(image = ImgBaseVermelho,width = 295,height = 295).place(x=450,y=0) 
    
    while(horizontal != 300):
        vertical = 0
        while (vertical != 150):
            if horizontal == 50 and vertical == 100:
                tk.Label(image=ImgParadaVermelho, width=46, height=46).place(x=(300 + vertical), y=(0 + horizontal))
            elif horizontal == 100 and vertical == 0:
                tk.Label(image=ImgCaixaEstrela, width=46, height=46).place(x=(300 + vertical), y=(0 + horizontal))
            elif conserta_caixa == 2 and horizontal>0: 
                tk.Label(image=ImgCaixaVermelho, width=46, height=46).place(x=(300 + vertical), y=(0 + horizontal)) 
            else:
                tk.Label(image=ImgCaixaBranca, width=46, height=46).place(x=(300 + vertical), y=(0 + horizontal)) 
            vertical += 50
            conserta_caixa+=1
        conserta_caixa = 1
        horizontal+=50


    #Construindo o lado Azul
    vertical =  0 
    horizontal = 0
    conserta_caixa = 1 

    tk.Label(image = ImgBaseAzul,width = 295,height = 295).place(x=450,y=450) 
    while(horizontal != 300):
        vertical = 0
        while (vertical != 150):
            if horizontal == 200 and vertical == 100:
                tk.Label(image=ImgParadaAzul, width=46, height=46).place(x=(450 + horizontal), y=(300 + vertical))
            elif horizontal == 150 and vertical == 0:
                tk.Label(image=ImgCaixaEstrela, width=46, height=46).place(x=(450 + horizontal), y=(300 + vertical)) 
            elif conserta_caixa == 2 and horizontal<250: 
                tk.Label(image=ImgCaixaAzul, width=46, height=46).place(x=(450 + horizontal), y=(300 + vertical)) 
            else:
                tk.Label(image=ImgCaixaBranca, width=46, height=46).place(x=(450 + horizontal), y=(300 + vertical)) 
            vertical += 50
            conserta_caixa+=1
        conserta_caixa = 1
        horizontal+=50

    #Construindo o lado Amarelo
    vertical =  0 
    horizontal = 0
    conserta_caixa = 1 

    tk.Label(image = ImgBaseAmarelo,width = 295,height = 295).place(x=0,y=450) 
    while(horizontal != 300):
        vertical = 0
        while (vertical != 150):
            if horizontal == 200 and vertical == 0:
                tk.Label(image=ImgParadaAmarelo, width=46, height=46).place(x=(300 + vertical), y=(450 + horizontal)) 
            elif horizontal == 150 and vertical == 100:
                tk.Label(image=ImgCaixaEstrela, width=46, height=46).place(x=(300 + vertical), y=(450 + horizontal))
            elif conserta_caixa == 2 and horizontal<250: 
                tk.Label(image=ImgCaixaAmarelo, width=46, height=46).place(x=(300 + vertical), y=(450 + horizontal)) 
            else:
                tk.Label(image=ImgCaixaBranca, width=46, height=46).place(x=(300 + vertical), y=(450 + horizontal)) 
            vertical += 50
            conserta_caixa+=1
        conserta_caixa = 1
        horizontal+=50

Tabuleiro()


root.mainloop()